#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v ffprobe >/dev/null || { echo 'Missing ffprobe'; exit 1; }
ffprobe -v error -show_entries format=duration,size:stream=codec_name,codec_type,width,height,r_frame_rate -of json public/presenter_cropped.mp4
if [[ -e public/presenter_keyed.webm ]]; then
  echo '--- Keyed alpha media ---'
  ffprobe -v error -show_entries stream=codec_name,alpha_mode:stream_tags=alpha_mode -of json public/presenter_keyed.webm
fi
if [[ -e out/upwork_intro_final.mp4 ]]; then
  echo '--- Final output ---'
  ffprobe -v error -show_entries format=duration,size:stream=codec_name,codec_type,width,height,r_frame_rate -of json out/upwork_intro_final.mp4
fi
