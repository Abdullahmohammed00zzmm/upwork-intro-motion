# Work state

- Phase: **PREPARED / not started in Codex**
- Brief and storyboard: approved by user on 2026-11-21.
- Source: `public/presenter_cropped.mp4` included; no alpha generated yet.
- Real client assets: referenced in manifest; need staging.
- Next tasks: extract package, validate media, stage real assets, build Remotion composition, still checks, render final MP4, verify, commit and share link.

Codex: update this file whenever completing a meaningful step, noting output paths and unresolved problems; commit state before usage ends. If resuming later, read this file and continue from the latest completed phase rather than restarting.
